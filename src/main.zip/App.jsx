import React from "react";
import { OnboardingProvider } from "./components/Context/OnboardingContext";
import OnboardingApp from "./components/OnboardingApp";

function App() {
  return (
    <OnboardingProvider>
      <OnboardingApp />
    </OnboardingProvider>
  );
}

export default App;
