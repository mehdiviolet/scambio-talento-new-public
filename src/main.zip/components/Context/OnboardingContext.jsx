/* eslint-disable react-refresh/only-export-components */
import { createContext, useContext, useState } from "react";

// ... resto del codice identico

const OnboardingContext = createContext();

export const OnboardingProvider = ({ children }) => {
  // Stati esistenti...
  const [showReadyToStart, setShowReadyToStart] = useState(false);
  const [showQuickSetup, setShowQuickSetup] = useState(false);
  const [quickSetupStep, setQuickSetupStep] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [showAuth, setShowAuth] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [authMode, setAuthMode] = useState("login");
  const [signupStep, setSignupStep] = useState(1);
  const [showPassword, setShowPassword] = useState(false);

  // NUOVI STATI PER L'APP PRINCIPALE
  const [showDashboard, setShowDashboard] = useState(false);
  const [showProfile, setShowProfile] = useState(false); // NUOVO STATO
  const [isOnboardingComplete, setIsOnboardingComplete] = useState(false);
  const [userProfile, setUserProfile] = useState(null);

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    birthDate: "",
    password: "",
    confirmPassword: "",
    profilePhoto: null,
    skills: [],
    seekingSkills: [],
    languages: [],
    aboutMe: "",
    location: "",
    gallery: [],
    suggestEvents: true,
    additionalSkills: [],
    // NUOVI CAMPI
    xp: 0,
    level: 1,
    achievements: [],
  });

  // FUNZIONE PER COMPLETARE L'ONBOARDING
  const completeOnboarding = (profileData) => {
    setFormData((prev) => ({ ...prev, ...profileData }));
    setUserProfile(profileData);
    setIsOnboardingComplete(true);
    setShowDashboard(true);

    // Nasconde tutti gli stati di onboarding
    setShowOnboarding(false);
    setShowReadyToStart(false);
    setShowQuickSetup(false);
    setShowAuth(false);
    setShowProfile(false); // AGGIUNGI ANCHE QUESTO
  };

  return (
    <OnboardingContext.Provider
      value={{
        // Stati esistenti...
        isLoading,
        setIsLoading,
        showOnboarding,
        setShowOnboarding,
        showAuth,
        setShowAuth,
        currentSlide,
        setCurrentSlide,
        authMode,
        setAuthMode,
        signupStep,
        setSignupStep,
        showPassword,
        setShowPassword,
        formData,
        setFormData,
        showReadyToStart,
        setShowReadyToStart,
        showQuickSetup,
        setShowQuickSetup,
        quickSetupStep,
        setQuickSetupStep,

        // NUOVI VALORI
        showDashboard,
        setShowDashboard,
        showProfile,
        setShowProfile,
        isOnboardingComplete,
        setIsOnboardingComplete,
        userProfile,
        setUserProfile,
        completeOnboarding,
      }}
    >
      {children}
    </OnboardingContext.Provider>
  );
};

export const useOnboarding = () => useContext(OnboardingContext);
