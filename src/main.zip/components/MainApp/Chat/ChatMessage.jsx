import React from 'react';

const ChatMessage = () => {
  return (
    <div className="p-4">
      <h2 className="text-xl font-bold">ChatMessage</h2>
      <p className="text-gray-600">Componente in sviluppo...</p>
    </div>
  );
};

export default ChatMessage;
