import React from 'react';

const GroupChat = () => {
  return (
    <div className="p-4">
      <h2 className="text-xl font-bold">GroupChat</h2>
      <p className="text-gray-600">Componente in sviluppo...</p>
    </div>
  );
};

export default GroupChat;
