import React from 'react';

const CreateExperience = () => {
  return (
    <div className="p-4">
      <h2 className="text-xl font-bold">CreateExperience</h2>
      <p className="text-gray-600">Componente in sviluppo...</p>
    </div>
  );
};

export default CreateExperience;
