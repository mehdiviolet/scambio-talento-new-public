import React from "react";
import { Heart, MessageCircle } from "lucide-react";
import { playSound, SOUNDS } from "../../../utils/soundUtils";

const ProfileHeader = ({ userData = null }) => {
  // Mock data se non vengono passati dati reali
  const defaultUser = {
    firstName: "Sara",
    lastName: "Dormand",
    email: "sara@example.com",
    birthDate: "30.09.1995",
    location: "Torino",
    zone: "Vanchiglia",
    joinedDate: "Today",
    languages: [
      { name: "Inglese", flag: "🇬🇧" },
      { name: "Francese", flag: "🇫🇷" },
    ],
    level: 16,
    profilePhoto: null,
    avatar: "👩‍🎨", // Emoji di default se non c'è foto
  };

  const user = userData || defaultUser;

  const handleHeartClick = () => {
    playSound(SOUNDS.CLICK);
    console.log("Heart clicked");
  };

  const handleMessageClick = () => {
    playSound(SOUNDS.CLICK);
    console.log("Message clicked");
  };

  return (
    <div className="bg-white border border-gray-200 rounded-lg p-4 md:p-6 shadow-sm">
      {/* Main Content Area */}
      <div className="flex items-start justify-between">
        {/* Left Side - Avatar e Info */}
        <div className="flex items-start space-x-4">
          {/* Avatar */}
          <div className="w-16 h-16 md:w-20 md:h-20 rounded-full bg-orange-100 border-2 border-orange-200 flex items-center justify-center overflow-hidden flex-shrink-0">
            {user.profilePhoto ? (
              <img
                src={user.profilePhoto}
                alt={`${user.firstName} ${user.lastName}`}
                className="w-full h-full object-cover"
              />
            ) : (
              <span className="text-2xl md:text-3xl">{user.avatar}</span>
            )}
          </div>

          {/* User Info */}
          <div className="flex-1 min-w-0">
            {/* Nome */}
            <h1 className="text-xl md:text-2xl font-bold text-gray-900 mb-1">
              {user.firstName} {user.lastName}
            </h1>

            {/* Email */}
            <p className="text-sm md:text-base text-gray-600 mb-1">
              {user.email}
            </p>

            {/* Data di nascita */}
            <p className="text-sm md:text-base text-gray-600 mb-1">
              {user.birthDate}
            </p>

            {/* Città */}
            <p className="text-sm md:text-base text-gray-600 mb-1">
              <span className="font-medium">Città:</span> {user.location}
            </p>

            {/* Zona (optional) */}
            {user.zone && (
              <p className="text-sm md:text-base text-gray-600 mb-1">
                <span className="font-medium">Zona:</span> {user.zone}
              </p>
            )}

            {/* Joined date */}
            <p className="text-sm md:text-base text-gray-600 mb-3">
              <span className="font-medium">Joined:</span> {user.joinedDate}
            </p>

            {/* Languages */}
            <div className="flex items-center space-x-1">
              <span className="text-sm md:text-base text-gray-600 font-medium mr-2">
                Languages:
              </span>
              {user.languages.map((lang, index) => (
                <span
                  key={index}
                  className="text-lg md:text-xl"
                  title={lang.name}
                >
                  {lang.flag}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Right Side - Level Badge */}
        <div className="flex flex-col items-center ml-4">
          {/* Diamond Level Badge */}
          <div className="relative">
            {/* Diamond Icon */}
            <div className="w-8 h-8 md:w-10 md:h-10 bg-black transform rotate-45 flex items-center justify-center">
              <div className="w-6 h-6 md:w-8 md:h-8 bg-white transform -rotate-45 flex items-center justify-center">
                <span className="text-xs md:text-sm font-bold text-black transform rotate-45">
                  💎
                </span>
              </div>
            </div>

            {/* Level Number */}
            <div className="absolute -bottom-2 -right-2 bg-black text-white text-sm md:text-base font-bold px-2 py-1 rounded-full min-w-[24px] h-6 flex items-center justify-center">
              {user.level}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Action Icons */}
      <div className="flex items-center justify-end space-x-4 mt-4 pt-4 border-t border-gray-100">
        {/* Heart Icon */}
        <button
          onClick={handleHeartClick}
          className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
          title="Like Profile"
        >
          <Heart className="w-5 h-5 text-gray-600 hover:text-red-500 transition-colors" />
        </button>

        {/* Message Icon */}
        <button
          onClick={handleMessageClick}
          className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
          title="Send Message"
        >
          <MessageCircle className="w-5 h-5 text-gray-600 hover:text-blue-500 transition-colors" />
        </button>
      </div>
    </div>
  );
};

export default ProfileHeader;
