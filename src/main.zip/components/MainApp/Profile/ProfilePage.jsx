import React, { useState } from "react";
import { useOnboarding } from "@/components/Context/OnboardingContext";
import ProfileHeader from "./ProfileHeader";
import AddSkillModal from "@/components/MainApp/Shared/Modals/AddSkillModal";
import ViewSkillModal from "@/components/MainApp/Shared/Modals/ViewSkillModal";
import AddExperienceModal from "@/components/MainApp/Shared/Modals/AddExperienceModal";

const ProfilePage = () => {
  // ===== CONTEXT E STATI =====
  const { formData, setFormData } = useOnboarding();

  // Stati per i modals
  const [isAddSkillModalOpen, setIsAddSkillModalOpen] = useState(false);
  const [isViewSkillModalOpen, setIsViewSkillModalOpen] = useState(false);
  const [selectedSkill, setSelectedSkill] = useState(null);
  const [isAddExperienceModalOpen, setIsAddExperienceModalOpen] =
    useState(false);

  // ===== GESTIONE SKILLS =====

  // Funzione per salvare nuova skill
  const handleSaveSkill = (newSkill) => {
    console.log("Salvando nuova skill:", newSkill);
    setFormData((prev) => ({
      ...prev,
      skills: [...(prev.skills || []), newSkill],
    }));
  };

  // Funzione per aggiornare skill esistente
  const handleUpdateSkill = (updatedSkill) => {
    console.log("Aggiornando skill:", updatedSkill);
    setFormData((prev) => ({
      ...prev,
      skills: prev.skills.map((skill) =>
        skill.createdAt === updatedSkill.createdAt ? updatedSkill : skill
      ),
    }));
  };

  // Funzione per eliminare skill
  const handleDeleteSkill = (skillToDelete) => {
    console.log("Eliminando skill:", skillToDelete);
    setFormData((prev) => ({
      ...prev,
      skills: prev.skills.filter(
        (skill) => skill.createdAt !== skillToDelete.createdAt
      ),
    }));
  };

  // ===== GESTIONE ESPERIENZE =====

  // Funzione per salvare nuova esperienza
  const handleSaveExperience = (newExperience) => {
    console.log("Salvando nuova esperienza:", newExperience);
    setFormData((prev) => ({
      ...prev,
      experiences: [...(prev.experiences || []), newExperience],
    }));
  };

  // ===== GESTIONE MODALS =====

  // Apri modal per creare nuova skill
  const handleOpenAddSkillModal = () => {
    console.log("Aprendo modal creazione skill");
    setIsAddSkillModalOpen(true);
  };

  // Chiudi modal creazione skill
  const handleCloseAddSkillModal = () => {
    console.log("Chiudendo modal creazione skill");
    setIsAddSkillModalOpen(false);
  };

  // Apri modal per visualizzare/modificare skill esistente
  const handleSkillClick = (skill) => {
    console.log("Skill cliccata:", skill);
    setSelectedSkill(skill);
    setIsViewSkillModalOpen(true);
  };

  // Chiudi modal visualizzazione skill
  const handleCloseViewSkillModal = () => {
    console.log("Chiudendo modal visualizzazione skill");
    setIsViewSkillModalOpen(false);
    setSelectedSkill(null);
  };

  // ===== GESTIONE MODALS ESPERIENZE =====

  // Apri modal per creare esperienza
  const handleOpenAddExperienceModal = () => {
    console.log("Aprendo modal creazione esperienza");
    setIsAddExperienceModalOpen(true);
  };

  // Chiudi modal creazione esperienza
  const handleCloseAddExperienceModal = () => {
    console.log("Chiudendo modal creazione esperienza");
    setIsAddExperienceModalOpen(false);
  };

  // ===== DATI PER PROFILEHEADER =====
  const userData = {
    firstName: formData.firstName || "Sara",
    lastName: formData.lastName || "Dormand",
    email: formData.email || "sara@example.com",
    birthDate: formData.birthDate || "30.09.1995",
    location: formData.location || "Torino",
    zone: "Vanchiglia",
    joinedDate: "Today",
    languages: formData.languages || [
      { name: "Inglese", flag: "🇬🇧" },
      { name: "Francese", flag: "🇫🇷" },
    ],
    level: formData.level || 16,
    profilePhoto: formData.profilePhoto
      ? URL.createObjectURL(formData.profilePhoto)
      : null,
    avatar: "👩‍🎨",
  };

  // ===== RENDER COMPONENT =====
  return (
    <div className="min-h-screen bg-gray-50">
      {/* CONTENUTO PRINCIPALE */}
      <div className="max-w-2xl mx-auto px-4 py-6 space-y-6">
        {/* ===== PROFILE HEADER ===== */}
        <ProfileHeader userData={userData} />

        {/* ===== ABOUT ME SECTION ===== */}
        <div className="bg-white border border-gray-200 rounded-lg p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4 bg-teal-100 px-3 py-2 rounded">
            About me:
          </h2>
          <p className="text-gray-600 leading-relaxed">
            {formData.aboutMe ||
              "Mi chiamo Sara e sono un'artista appassionata di pittura a olio e musica. Creativa, curiosa e sempre in cerca di nuove ispirazioni. Amo l'arte in tutte le sue forme e credo nel potere delle esperienze condivise. Mi piace imparare, sperimentare e conoscere persone con le stesse passioni."}
          </p>
        </div>

        {/* ===== BASIC SKILLS SECTION ===== */}
        <div className="bg-white border border-gray-200 rounded-lg p-6">
          {/* Header sezione con bottone + */}
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">
              Basic skills:
            </h2>
            <button
              onClick={handleOpenAddSkillModal}
              className="w-8 h-8 bg-green-500 text-white rounded-full flex items-center justify-center hover:bg-green-600 transition-all duration-200 shadow-md hover:shadow-lg transform hover:scale-105"
              title="Aggiungi nuova skill"
            >
              <span className="text-lg font-bold leading-none">+</span>
            </button>
          </div>

          {/* Lista skills */}
          <div className="space-y-3">
            {formData.skills && formData.skills.length > 0 ? (
              formData.skills.map((skill, index) => (
                <div
                  key={`skill-${index}-${skill.createdAt}`}
                  onClick={() => handleSkillClick(skill)}
                  className="flex items-center justify-between p-4 bg-orange-50 rounded-lg border border-orange-200 cursor-pointer hover:shadow-md hover:bg-orange-100 transition-all duration-200 transform hover:scale-[1.01]"
                  title="Clicca per visualizzare dettagli"
                >
                  {/* Parte sinistra - icona e info */}
                  <div className="flex items-center space-x-3 flex-1">
                    <span className="text-2xl">{skill.icon}</span>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-gray-900 truncate">
                        {skill.detail || skill.name}
                      </div>
                      {skill.description && (
                        <p className="text-xs text-gray-600 mt-1 line-clamp-2 max-w-xs">
                          {skill.description}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Parte destra - stats */}
                  <div className="flex items-center space-x-3 flex-shrink-0">
                    <span className="text-sm text-gray-500 flex items-center">
                      <span className="mr-1">⚡</span>
                      <span className="font-medium">{skill.gems || 0}</span>
                    </span>
                    <div className="w-6 h-6 bg-gray-200 rounded-full flex items-center justify-center">
                      <span className="text-xs">👁️</span>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              /* Stato vuoto */
              <div className="text-center py-12 text-gray-500">
                <div className="text-4xl mb-4">🎯</div>
                <p className="text-lg font-medium mb-2">
                  Nessuna skill aggiunta ancora
                </p>
                <p className="text-sm">
                  Clicca il pulsante + per aggiungere la tua prima competenza
                </p>
              </div>
            )}
          </div>
        </div>

        {/* ===== SEZIONI ESPERIENZE E RICERCA ===== */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Esperienze Offerte */}
          <div className="bg-white border border-gray-200 rounded-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-900 flex items-center">
                <span className="mr-2">📚</span>
                Esperienze Offerte
              </h3>
              {formData.skills && formData.skills.length > 0 ? (
                <button
                  onClick={handleOpenAddExperienceModal}
                  className="w-8 h-8 bg-green-500 text-white rounded-full flex items-center justify-center hover:bg-green-600 transition-all duration-200 shadow-md hover:shadow-lg transform hover:scale-105"
                  title="Crea nuova esperienza"
                >
                  <span className="text-lg font-bold leading-none">+</span>
                </button>
              ) : (
                <div className="text-xs text-gray-400 bg-gray-100 px-3 py-1 rounded-full">
                  Aggiungi prima una skill
                </div>
              )}
            </div>

            {/* Lista esperienze */}
            <div className="space-y-3">
              {formData.experiences && formData.experiences.length > 0 ? (
                formData.experiences.map((experience, index) => (
                  <div
                    key={index}
                    className="p-3 bg-green-50 rounded-lg border border-green-200 hover:shadow-sm transition-shadow cursor-pointer"
                  >
                    <div className="flex items-start space-x-3">
                      <span className="text-xl">{experience.skillIcon}</span>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-gray-900 truncate">
                          {experience.title}
                        </h4>
                        <p className="text-xs text-gray-600 mt-1">
                          {experience.level} • {experience.duration} •{" "}
                          {experience.sessions} sessioni
                        </p>
                        <div className="flex items-center justify-between mt-2">
                          <span className="text-xs text-green-600 font-medium">
                            💎 {experience.costGems} GEM
                          </span>
                          <span className="text-xs text-gray-500">
                            👥 {experience.participants}/
                            {experience.maxParticipants}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-6 text-gray-500">
                  {formData.skills && formData.skills.length > 0 ? (
                    <>
                      <div className="text-2xl mb-2">🎓</div>
                      <p className="text-sm">Nessuna esperienza creata</p>
                      <p className="text-xs mt-1">
                        Clicca + per creare la tua prima esperienza
                      </p>
                    </>
                  ) : (
                    <>
                      <div className="text-2xl mb-2">🎯</div>
                      <p className="text-sm">Aggiungi prima una skill</p>
                      <p className="text-xs mt-1">
                        Le esperienze si basano sulle tue competenze
                      </p>
                    </>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Alla Ricerca */}
          <div className="bg-white border border-gray-200 rounded-lg p-6">
            <h3 className="font-semibold text-gray-900 mb-4 flex items-center">
              <span className="mr-2">🎯</span>
              Alla Ricerca
            </h3>
            <div className="text-center py-6 text-gray-500">
              <div className="text-2xl mb-2">🔍</div>
              <p className="text-sm">Prossimamente disponibile...</p>
            </div>
          </div>
        </div>

        {/* Sezione Eventi Partecipati */}
        <div className="bg-white border border-gray-200 rounded-lg p-6">
          <h3 className="font-semibold text-gray-900 mb-4 flex items-center">
            <span className="mr-2">📅</span>
            Eventi Partecipati
          </h3>
          <div className="text-center py-8 text-gray-500">
            <div className="text-3xl mb-2">🎪</div>
            <p>Nessun evento ancora</p>
          </div>
        </div>

        {/* Gallery */}
        <div className="bg-white border border-gray-200 rounded-lg p-6">
          <h3 className="font-semibold text-gray-900 mb-4 flex items-center">
            <span className="mr-2">🖼️</span>
            Gallery (artworks - esperienze - events)
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="aspect-square bg-gray-100 rounded-lg flex items-center justify-center border-2 border-dashed border-gray-300 hover:border-gray-400 transition-colors cursor-pointer">
              <span className="text-gray-400 text-3xl">📸</span>
            </div>
            <div className="aspect-square bg-gray-100 rounded-lg flex items-center justify-center border-2 border-dashed border-gray-300 hover:border-gray-400 transition-colors cursor-pointer">
              <span className="text-gray-400 text-3xl">🎨</span>
            </div>
          </div>
        </div>

        {/* Azioni Loan/Invite */}
        <div className="flex space-x-4">
          <button className="flex-1 bg-teal-400 hover:bg-teal-500 text-white py-3 rounded-lg font-semibold transition-colors transform hover:scale-[1.02]">
            💰 Loan GEM
          </button>
          <button className="flex-1 bg-teal-300 hover:bg-teal-400 text-teal-800 py-3 rounded-lg font-semibold transition-colors transform hover:scale-[1.02]">
            👥 Invite Friends
          </button>
        </div>
      </div>

      {/* ===== MODALS ===== */}

      {/* Modal per aggiungere skill */}
      <AddSkillModal
        isOpen={isAddSkillModalOpen}
        onClose={handleCloseAddSkillModal}
        onSave={handleSaveSkill}
        formData={formData}
      />

      {/* Modal per visualizzare/modificare skill */}
      <ViewSkillModal
        isOpen={isViewSkillModalOpen}
        onClose={handleCloseViewSkillModal}
        skill={selectedSkill}
        onUpdate={handleUpdateSkill}
        onDelete={handleDeleteSkill}
        formData={formData}
      />

      {/* Modal per aggiungere esperienza */}
      <AddExperienceModal
        isOpen={isAddExperienceModalOpen}
        onClose={handleCloseAddExperienceModal}
        onSave={handleSaveExperience}
        userSkills={formData.skills || []}
        formData={formData}
      />
    </div>
  );
};

export default ProfilePage;
