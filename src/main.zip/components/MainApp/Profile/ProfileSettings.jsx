import React from 'react';

const ProfileSettings = () => {
  return (
    <div className="p-4">
      <h2 className="text-xl font-bold">ProfileSettings</h2>
      <p className="text-gray-600">Componente in sviluppo...</p>
    </div>
  );
};

export default ProfileSettings;
