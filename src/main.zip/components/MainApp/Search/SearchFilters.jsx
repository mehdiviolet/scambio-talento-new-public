import React from 'react';

const SearchFilters = () => {
  return (
    <div className="p-4">
      <h2 className="text-xl font-bold">SearchFilters</h2>
      <p className="text-gray-600">Componente in sviluppo...</p>
    </div>
  );
};

export default SearchFilters;
