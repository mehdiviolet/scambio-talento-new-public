import React from 'react';

const SettingsPage = () => {
  return (
    <div className="p-4">
      <h2 className="text-xl font-bold">SettingsPage</h2>
      <p className="text-gray-600">Componente in sviluppo...</p>
    </div>
  );
};

export default SettingsPage;
