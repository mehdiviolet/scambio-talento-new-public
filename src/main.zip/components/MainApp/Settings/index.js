export { default as SettingsPage } from './SettingsPage';
export { default as AccountSettings } from './AccountSettings';
export { default as NotificationSettings } from './NotificationSettings';
export { default as PrivacySettings } from './PrivacySettings';
export { default as LanguageSettings } from './LanguageSettings';
export { default as HelpSupport } from './HelpSupport';