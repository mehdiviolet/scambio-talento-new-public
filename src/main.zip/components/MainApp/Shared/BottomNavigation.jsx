import React from "react";
import { Home, Search, Building, MessageCircle, User } from "lucide-react";

const BottomNavigation = ({ activeTab, onTabChange }) => {
  const tabs = [
    { id: "home", icon: Home, label: "Home" },
    { id: "search", icon: Search, label: "Cerca" },
    { id: "explore", icon: Building, label: "Esplora" },
    { id: "chat", icon: MessageCircle, label: "Chat", badge: 3 },
    { id: "profile", icon: User, label: "Profilo" },
  ];

  const handleTabClick = (tabId) => {
    onTabChange(tabId);
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg">
      <div className="max-w-md mx-auto px-4">
        <div className="flex items-center justify-around py-2">
          {tabs.map((tab) => {
            const IconComponent = tab.icon;
            const isActive = activeTab === tab.id;

            return (
              <button
                key={tab.id}
                onClick={() => handleTabClick(tab.id)}
                className={`flex flex-col items-center py-2 px-3 rounded-lg transition-all relative ${
                  isActive
                    ? "text-purple-600 bg-purple-50"
                    : "text-gray-600 hover:text-purple-600 hover:bg-gray-50"
                }`}
              >
                <div className="relative">
                  <IconComponent className="w-5 h-5 mb-1" />
                  {tab.badge && (
                    <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
                      {tab.badge}
                    </span>
                  )}
                </div>
                <span className="text-xs">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default BottomNavigation;
