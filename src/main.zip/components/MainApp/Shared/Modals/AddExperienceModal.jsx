import React, { useState, useEffect, useRef } from "react";
import { X, ChevronDown } from "lucide-react";

const AddExperienceModal = ({
  isOpen,
  onClose,
  onSave,
  userSkills,
  formData,
}) => {
  const [currentStep, setCurrentStep] = useState(1); // 1: Select Skill, 2: Experience Details
  const [selectedSkill, setSelectedSkill] = useState(null);
  const [experienceData, setExperienceData] = useState({
    title: "",
    description: "",
    level: "Principiante",
    duration: "",
    sessions: 1,
    costGems: 10,
    maxParticipants: 2,
  });

  const titleRef = useRef(null);
  const descriptionRef = useRef(null);

  // Opzioni per i dropdown
  const levelOptions = [
    { value: "Principiante", label: "Principiante", icon: "🌱" },
    { value: "Intermedio", label: "Intermedio", icon: "⚡" },
    { value: "Avanzato", label: "Avanzato", icon: "🔥" },
  ];

  const gemOptions = [
    { value: 10, label: "10 GEM", color: "text-green-600" },
    { value: 20, label: "20 GEM", color: "text-green-600" },
    { value: 30, label: "30 GEM", color: "text-blue-600" },
    { value: 40, label: "40 GEM", color: "text-blue-600" },
    { value: 50, label: "50 GEM", color: "text-purple-600" },
    { value: 60, label: "60 GEM", color: "text-purple-600" },
    { value: 70, label: "70 GEM", color: "text-red-600" },
    { value: 80, label: "80 GEM", color: "text-red-600" },
  ];

  const participantOptions = [
    { value: 1, label: "1 persona", icon: "👤" },
    { value: 2, label: "2 persone", icon: "👥" },
    { value: 3, label: "3 persone", icon: "👥" },
    { value: 4, label: "4 persone", icon: "👥" },
  ];

  // Reset quando si apre
  useEffect(() => {
    if (isOpen) {
      setCurrentStep(1);
      setSelectedSkill(null);
      setExperienceData({
        title: "",
        description: "",
        level: "Principiante",
        duration: "",
        sessions: 1,
        costGems: 10,
        maxParticipants: 2,
      });
    }
  }, [isOpen]);

  // Focus automatico
  useEffect(() => {
    if (currentStep === 2) {
      setTimeout(() => {
        if (titleRef.current) titleRef.current.focus();
      }, 100);
    }
  }, [currentStep]);

  const handleSkillSelect = (skill) => {
    setSelectedSkill(skill);
    setExperienceData((prev) => ({
      ...prev,
      title: `Corso di ${skill.name}`,
    }));
    setCurrentStep(2);
  };

  const handleInputChange = (field, value) => {
    setExperienceData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const canSave = () => {
    return (
      selectedSkill &&
      experienceData.title.trim() &&
      experienceData.description.trim() &&
      experienceData.duration.trim()
    );
  };

  const handleSave = () => {
    if (!canSave()) return;

    const newExperience = {
      id: `exp-${Date.now()}`,
      skillId: selectedSkill.id,
      skillName: selectedSkill.name,
      skillIcon: selectedSkill.icon,
      skillDetail: selectedSkill.detail || selectedSkill.name,
      title: experienceData.title.trim(),
      description: experienceData.description.trim(),
      level: experienceData.level,
      duration: experienceData.duration.trim(),
      sessions: experienceData.sessions,
      costGems: experienceData.costGems,
      maxParticipants: experienceData.maxParticipants,
      participants: 0,
      status: "Attiva",
      createdAt: new Date().toISOString(),
    };

    onSave(newExperience);
    onClose();
  };

  const handleOverlayClick = (e) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  if (!isOpen) return null;

  // Se non ci sono skills, mostra messaggio
  if (!userSkills || userSkills.length === 0) {
    return (
      <div
        className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
        onClick={handleOverlayClick}
      >
        <div className="bg-white rounded-2xl max-w-md w-full p-6 text-center">
          <div className="text-6xl mb-4">🎯</div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Nessuna Skill Disponibile
          </h2>
          <p className="text-gray-600 mb-6">
            Per creare un'esperienza devi prima aggiungere almeno una competenza
            nella sezione "Basic Skills".
          </p>
          <button
            onClick={onClose}
            className="w-full bg-purple-500 text-white py-3 rounded-lg hover:bg-purple-600 transition-colors font-semibold"
          >
            Ho Capito
          </button>
        </div>
      </div>
    );
  }

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      onClick={handleOverlayClick}
    >
      <div className="bg-white rounded-2xl max-w-md w-full max-h-[90vh] overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="bg-green-100 p-4 rounded-t-2xl relative">
          <h2 className="text-lg font-semibold text-gray-800 text-center">
            {currentStep === 1 && "Scegli una competenza"}
            {currentStep === 2 && "Crea la tua esperienza"}
          </h2>
          <button
            onClick={onClose}
            className="absolute right-4 top-4 p-1 rounded-full hover:bg-green-200 transition-colors"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        <div className="p-6 max-h-[calc(90vh-80px)] overflow-y-auto">
          {/* Step 1: Selezione Skill */}
          {currentStep === 1 && (
            <div className="space-y-4">
              <div className="text-center mb-6">
                <h3 className="text-lg font-bold text-gray-900 mb-2">
                  Le tue competenze
                </h3>
                <p className="text-sm text-gray-600">
                  Seleziona la skill su cui basare l'esperienza
                </p>
              </div>

              <div className="space-y-3">
                {userSkills.map((skill) => (
                  <div
                    key={skill.id}
                    onClick={() => handleSkillSelect(skill)}
                    className="flex items-center p-4 bg-gray-50 rounded-xl border-2 border-gray-200 hover:border-green-400 hover:bg-green-50 cursor-pointer transition-all transform hover:scale-[1.02]"
                  >
                    <span className="text-2xl mr-3">{skill.icon}</span>
                    <div className="flex-1">
                      <div className="font-semibold text-gray-900">
                        {skill.detail || skill.name}
                      </div>
                      <div className="text-sm text-gray-600 flex items-center mt-1">
                        <span className="mr-1">⚡</span>
                        <span>{skill.gems || 0} GEM</span>
                      </div>
                    </div>
                    <ChevronDown className="w-5 h-5 text-gray-400 transform rotate-[-90deg]" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Step 2: Dettagli Esperienza */}
          {currentStep === 2 && selectedSkill && (
            <div className="space-y-6">
              {/* Header skill selezionata */}
              <div className="text-center p-4 bg-green-50 rounded-xl">
                <span className="text-3xl mb-2 block">
                  {selectedSkill.icon}
                </span>
                <h3 className="font-bold text-gray-900">
                  {selectedSkill.detail || selectedSkill.name}
                </h3>
                <p className="text-sm text-gray-600">Skill selezionata</p>
              </div>

              {/* Titolo esperienza */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Titolo dell'esperienza *
                </label>
                <input
                  ref={titleRef}
                  type="text"
                  value={experienceData.title}
                  onChange={(e) => handleInputChange("title", e.target.value)}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:border-green-500 focus:ring-0 transition-colors"
                  placeholder="es. Corso base di Acquerello"
                />
              </div>

              {/* Descrizione */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Descrizione *
                </label>
                <textarea
                  ref={descriptionRef}
                  value={experienceData.description}
                  onChange={(e) =>
                    handleInputChange("description", e.target.value)
                  }
                  rows={3}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:border-green-500 focus:ring-0 transition-colors resize-none"
                  placeholder="Descrivi cosa insegnerai, cosa impareranno i partecipanti..."
                />
              </div>

              {/* Grid con opzioni */}
              <div className="grid grid-cols-2 gap-4">
                {/* Livello */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Livello
                  </label>
                  <select
                    value={experienceData.level}
                    onChange={(e) => handleInputChange("level", e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:border-green-500 focus:ring-0 transition-colors"
                  >
                    {levelOptions.map((option) => (
                      <option key={option.value} value={option.value}>
                        {option.icon} {option.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Partecipanti */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Partecipanti
                  </label>
                  <select
                    value={experienceData.maxParticipants}
                    onChange={(e) =>
                      handleInputChange(
                        "maxParticipants",
                        parseInt(e.target.value)
                      )
                    }
                    className="w-full p-3 border border-gray-300 rounded-lg focus:border-green-500 focus:ring-0 transition-colors"
                  >
                    {participantOptions.map((option) => (
                      <option key={option.value} value={option.value}>
                        {option.icon} {option.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Durata e Sessioni */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Durata per sessione *
                  </label>
                  <input
                    type="text"
                    value={experienceData.duration}
                    onChange={(e) =>
                      handleInputChange("duration", e.target.value)
                    }
                    className="w-full p-3 border border-gray-300 rounded-lg focus:border-green-500 focus:ring-0 transition-colors"
                    placeholder="es. 2 ore"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Numero sessioni
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="20"
                    value={experienceData.sessions}
                    onChange={(e) =>
                      handleInputChange(
                        "sessions",
                        parseInt(e.target.value) || 1
                      )
                    }
                    className="w-full p-3 border border-gray-300 rounded-lg focus:border-green-500 focus:ring-0 transition-colors"
                  />
                </div>
              </div>

              {/* Costo */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Costo
                </label>
                <select
                  value={experienceData.costGems}
                  onChange={(e) =>
                    handleInputChange("costGems", parseInt(e.target.value))
                  }
                  className="w-full p-3 border border-gray-300 rounded-lg focus:border-green-500 focus:ring-0 transition-colors"
                >
                  {gemOptions.map((option) => (
                    <option key={option.value} value={option.value}>
                      💎 {option.label}
                    </option>
                  ))}
                </select>
              </div>

              {/* Pulsanti */}
              <div className="flex space-x-3 pt-4">
                <button
                  onClick={() => setCurrentStep(1)}
                  className="flex-1 py-3 px-4 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Indietro
                </button>
                <button
                  onClick={handleSave}
                  disabled={!canSave()}
                  className={`flex-1 py-3 px-4 rounded-lg transition-colors font-semibold ${
                    canSave()
                      ? "bg-green-500 text-white hover:bg-green-600"
                      : "bg-gray-300 text-gray-500 cursor-not-allowed"
                  }`}
                >
                  🎉 Crea Esperienza
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AddExperienceModal;
