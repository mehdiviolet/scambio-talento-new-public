import React, { useState, useEffect } from "react";
import { X, Edit3, Trash2, Save } from "lucide-react";

const ViewSkillModal = ({
  isOpen,
  onClose,
  skill,
  onUpdate,
  onDelete,
  formData,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedDetail, setEditedDetail] = useState("");
  const [editedDescription, setEditedDescription] = useState("");

  // Carica i dati della skill quando si apre
  useEffect(() => {
    if (isOpen && skill) {
      setEditedDetail(skill.detail || skill.name);
      setEditedDescription(skill.description || "");
      setIsEditing(false);
    }
  }, [isOpen, skill]);

  const handleEdit = () => {
    setIsEditing(true);
  };

  const handleSave = () => {
    const updatedSkill = {
      ...skill,
      detail: editedDetail.trim(),
      description: editedDescription.trim(),
      updatedAt: new Date().toISOString(),
    };
    onUpdate(updatedSkill);
    setIsEditing(false);
    onClose();
  };

  const handleCancel = () => {
    // Ripristina i valori originali
    setEditedDetail(skill.detail || skill.name);
    setEditedDescription(skill.description || "");
    setIsEditing(false);
  };

  const handleDelete = () => {
    if (
      window.confirm(
        `Sei sicuro di voler eliminare la skill "${
          skill.detail || skill.name
        }"?`
      )
    ) {
      onDelete(skill);
      onClose();
    }
  };

  const handleOverlayClick = (e) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  if (!isOpen || !skill) return null;

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      onClick={handleOverlayClick}
    >
      <div className="max-w-md w-full space-y-6">
        {/* Header con titolo e close button */}
        <div className="flex items-center justify-between text-white">
          <h2 className="text-xl font-semibold">
            {isEditing ? "Modifica Skill" : "Dettagli Skill"}
          </h2>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-white hover:bg-opacity-20 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* LA CARTA - Esattamente come nell'immagine */}
        <div className="bg-gradient-to-br from-orange-300 via-orange-200 to-orange-100 rounded-3xl p-6 shadow-2xl">
          {/* Titolo della skill */}
          <div className="mb-6">
            {isEditing ? (
              <input
                type="text"
                value={editedDetail}
                onChange={(e) => setEditedDetail(e.target.value)}
                className="w-full text-xl font-bold text-gray-900 bg-transparent border-b-2 border-gray-600 focus:border-gray-800 focus:outline-none pb-1"
                placeholder="Skill / Dettaglio"
              />
            ) : (
              <h3 className="text-xl font-bold text-gray-900">
                {editedDetail}
              </h3>
            )}
          </div>

          {/* Box descrizione - Come nell'immagine */}
          <div className="bg-white bg-opacity-70 rounded-2xl p-4 mb-6 shadow-inner">
            {isEditing ? (
              <textarea
                value={editedDescription}
                onChange={(e) => setEditedDescription(e.target.value)}
                rows={5}
                className="w-full bg-transparent focus:outline-none text-gray-800 leading-relaxed resize-none"
                placeholder="Descrivi la tua esperienza..."
              />
            ) : (
              <p className="text-gray-800 leading-relaxed">
                {editedDescription || "Nessuna descrizione disponibile"}
              </p>
            )}
          </div>

          {/* Linea tratteggiata */}
          <div className="border-t-2 border-dashed border-gray-400 mb-4"></div>

          {/* Footer con info utente - Esattamente come nell'immagine */}
          <div className="flex items-center justify-between">
            {/* Avatar e nome */}
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 rounded-full overflow-hidden bg-orange-300 flex items-center justify-center">
                {formData?.profilePhoto ? (
                  <img
                    src={URL.createObjectURL(formData.profilePhoto)}
                    alt="Profile"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <span className="text-2xl">👩‍🎨</span>
                )}
              </div>
              <span className="font-bold text-gray-900 text-lg">
                {formData?.firstName || "Sara"}{" "}
                {formData?.lastName || "Dormand"}
              </span>
            </div>

            {/* GEM counter con icona */}
            <div className="flex items-center space-x-2">
              <div className="flex items-center space-x-1">
                <span className="text-xl">⚡</span>
                <span className="font-bold text-gray-900 text-lg">
                  {skill.gems || 0}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* BOTTONI AZIONE - Fuori dalla carta */}
        {isEditing ? (
          /* Modalità editing */
          <div className="flex space-x-4">
            <button
              onClick={handleCancel}
              className="flex-1 flex items-center justify-center space-x-2 py-3 px-6 bg-gray-600 hover:bg-gray-700 text-white rounded-xl transition-colors font-semibold"
            >
              <X className="w-5 h-5" />
              <span>Annulla</span>
            </button>
            <button
              onClick={handleSave}
              disabled={!editedDetail.trim() || !editedDescription.trim()}
              className={`flex-1 flex items-center justify-center space-x-2 py-3 px-6 rounded-xl transition-colors font-semibold ${
                editedDetail.trim() && editedDescription.trim()
                  ? "bg-green-500 hover:bg-green-600 text-white"
                  : "bg-gray-400 text-gray-600 cursor-not-allowed"
              }`}
            >
              <Save className="w-5 h-5" />
              <span>Salva</span>
            </button>
          </div>
        ) : (
          /* Modalità visualizzazione */
          <div className="space-y-4">
            {/* Statistiche extra */}
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center p-4 bg-white bg-opacity-90 rounded-xl">
                <div className="text-2xl font-bold text-blue-600">0</div>
                <div className="text-xs text-gray-600 font-medium">
                  Richieste
                </div>
              </div>
              <div className="text-center p-4 bg-white bg-opacity-90 rounded-xl">
                <div className="text-2xl font-bold text-green-600">0</div>
                <div className="text-xs text-gray-600 font-medium">
                  Completate
                </div>
              </div>
              <div className="text-center p-4 bg-white bg-opacity-90 rounded-xl">
                <div className="text-2xl font-bold text-yellow-600">⭐</div>
                <div className="text-xs text-gray-600 font-medium">Rating</div>
              </div>
            </div>

            {/* Bottoni principali */}
            <div className="flex space-x-4">
              <button
                onClick={handleEdit}
                className="flex-1 flex items-center justify-center space-x-2 py-3 px-6 bg-blue-500 hover:bg-blue-600 text-white rounded-xl transition-colors font-semibold shadow-lg transform hover:scale-105"
              >
                <Edit3 className="w-5 h-5" />
                <span>Modifica</span>
              </button>
              <button
                onClick={handleDelete}
                className="flex-1 flex items-center justify-center space-x-2 py-3 px-6 bg-red-500 hover:bg-red-600 text-white rounded-xl transition-colors font-semibold shadow-lg transform hover:scale-105"
              >
                <Trash2 className="w-5 h-5" />
                <span>Elimina</span>
              </button>
            </div>

            {/* Info aggiuntive */}
            <div className="bg-white bg-opacity-90 rounded-xl p-4">
              <div className="flex items-center justify-between text-sm text-gray-600">
                <span>
                  Creata il {new Date(skill.createdAt).toLocaleDateString()}
                </span>
                <span className="flex items-center space-x-1">
                  <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                  <span>Attiva</span>
                </span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ViewSkillModal;
