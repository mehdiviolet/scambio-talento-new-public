import React, { useState } from "react";
import BottomNavigation from "./MainApp/Shared/BottomNavigation";
import ProfilePage from "./MainApp/Profile/ProfilePage"; // IMPORT VERO

// Placeholder components per ora
const HomePage = () => (
  <div className="p-6">
    <h1 className="text-2xl font-bold mb-4">🏠 Home</h1>
    <p className="text-gray-600">Lista persone nelle vicinanze</p>
    <div className="mt-4 space-y-3">
      <div className="bg-white p-4 rounded-lg border">
        <h3 className="font-semibold">Marco Rossi</h3>
        <p className="text-sm text-gray-600">Insegna: Chitarra, Fotografia</p>
        <p className="text-sm text-blue-600">Cerca: Cucina</p>
      </div>
      <div className="bg-white p-4 rounded-lg border">
        <h3 className="font-semibold">Giulia Bianchi</h3>
        <p className="text-sm text-gray-600">Insegna: Cucina, Lingue</p>
        <p className="text-sm text-blue-600">Cerca: Programmazione</p>
      </div>
    </div>
  </div>
);

const SearchPage = () => (
  <div className="p-6">
    <h1 className="text-2xl font-bold mb-4">🔍 Cerca</h1>
    <input
      type="text"
      placeholder="Cerca persone o skill..."
      className="w-full p-3 border rounded-lg mb-4"
    />
    <p className="text-gray-600">Ricerca persone per skill</p>
  </div>
);

const ExplorePage = () => (
  <div className="p-6">
    <h1 className="text-2xl font-bold mb-4">🏛️ Esplora</h1>
    <p className="text-gray-600">Esperienze disponibili</p>
    <div className="mt-4 space-y-3">
      <div className="bg-green-50 p-4 rounded-lg border border-green-200">
        <h3 className="font-semibold">Lezioni di Chitarra</h3>
        <p className="text-sm text-gray-600">Insegnante: Marco Rossi</p>
        <p className="text-sm text-green-600">Costo: 15 GEM</p>
      </div>
    </div>
  </div>
);

const ChatPage = () => (
  <div className="p-6">
    <h1 className="text-2xl font-bold mb-4">💬 Chat</h1>
    <p className="text-gray-600">Conversazioni</p>
    <div className="mt-4 space-y-3">
      <div className="bg-white p-4 rounded-lg border">
        <h3 className="font-semibold">Marco Rossi</h3>
        <p className="text-sm text-gray-600">
          Ciao! Quando possiamo iniziare le lezioni?
        </p>
        <p className="text-xs text-gray-400">2 min fa</p>
      </div>
    </div>
  </div>
);

const MainAppRouter = () => {
  const [activeTab, setActiveTab] = useState("home");

  const renderCurrentPage = () => {
    switch (activeTab) {
      case "home":
        return <HomePage />;
      case "search":
        return <SearchPage />;
      case "explore":
        return <ExplorePage />;
      case "chat":
        return <ChatPage />;
      case "profile":
        return <ProfilePage />; // USA IL COMPONENTE VERO
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header semplice */}
      <div className="bg-white shadow-sm border-b sticky top-0 z-40">
        <div className="max-w-md mx-auto px-4 py-3">
          <h1 className="text-xl font-bold text-purple-600">Scambio Talento</h1>
        </div>
      </div>

      {/* Content area */}
      <div className="pb-16">
        {" "}
        {/* Bottom padding per il menu */}
        {renderCurrentPage()}
      </div>

      {/* Bottom Navigation */}
      <BottomNavigation activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  );
};

export default MainAppRouter;
