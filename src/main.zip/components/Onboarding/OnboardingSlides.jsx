import React, { useState } from "react";
import {
  Users,
  MessageCircle,
  Calendar,
  ChevronLeft,
  ChevronRight,
  ArrowRight,
} from "lucide-react";
import { useOnboarding } from "../Context/OnboardingContext"; // IMPORTA CONTEXTO

const OnboardingSlides = () => {
  const {
    currentSlide,
    setCurrentSlide,
    setShowOnboarding,
    setShowAuth,
    setShowReadyToStart,
  } = useOnboarding();

  const [isTransitioning, setIsTransitioning] = useState(false);

  const slides = [
    {
      icon: Users,
      title: "Connetti con persone",
      subtitle: "Trova persone con le tue stesse passioni",
      description:
        "Scopri una comunità di persone che condividono i tuoi interessi e le tue competenze. Costruisci relazioni autentiche basate sulla passione comune.",
      color: "from-blue-500 to-cyan-500",
      bgPattern: "circles",
    },
    {
      icon: MessageCircle,
      title: "Scambia competenze",
      subtitle: "Impara e insegna allo stesso tempo",
      description:
        "Condividi quello che sai e apprendi nuove competenze. Ogni scambio è un'opportunità di crescita personale e professionale.",
      color: "from-purple-500 to-pink-500",
      bgPattern: "waves",
    },
    {
      icon: Calendar,
      title: "Organizza eventi",
      subtitle: "Crea momenti di condivisione",
      description:
        "Organizza workshop, meetup e eventi per la tua comunità. Trasforma le competenze in esperienze memorabili.",
      color: "from-emerald-500 to-teal-500",
      bgPattern: "dots",
    },
  ];

  const nextSlide = () => {
    if (currentSlide < slides.length - 1) {
      setIsTransitioning(true);
      setTimeout(() => {
        setCurrentSlide(currentSlide + 1);
        setIsTransitioning(false);
      }, 150);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 0) {
      setIsTransitioning(true);
      setTimeout(() => {
        setCurrentSlide(currentSlide - 1);
        setIsTransitioning(false);
      }, 150);
    }
  };

  const goToSlide = (index) => {
    if (index !== currentSlide) {
      setIsTransitioning(true);
      setTimeout(() => {
        setCurrentSlide(index);
        setIsTransitioning(false);
      }, 150);
    }
  };

  const handleContinue = () => {
    if (currentSlide < slides.length - 1) {
      nextSlide();
    } else {
      // Ultima slide - vai alla "Ready to Start"
      setShowOnboarding(false);
      setShowReadyToStart(true);
    }
  };

  const handleSkip = () => {
    setShowOnboarding(false);
    setShowAuth(true);
  };

  const currentSlideData = slides[currentSlide];
  const IconComponent = currentSlideData.icon;

  return (
    <div className="min-h-screen bg-white flex flex-col relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 z-0">
        <div
          className={`absolute inset-0 bg-gradient-to-br ${currentSlideData.color} opacity-5 transition-all duration-700`}
        ></div>

        {/* Dynamic Background Patterns */}
        {currentSlideData.bgPattern === "circles" && (
          <div className="absolute inset-0 opacity-3">
            <div className="absolute top-10 left-10 w-32 h-32 bg-blue-200 rounded-full animate-pulse"></div>
            <div
              className="absolute top-32 right-16 w-24 h-24 bg-cyan-200 rounded-full animate-pulse"
              style={{ animationDelay: "1s" }}
            ></div>
            <div
              className="absolute bottom-20 left-20 w-40 h-40 bg-blue-100 rounded-full animate-pulse"
              style={{ animationDelay: "2s" }}
            ></div>
          </div>
        )}

        {currentSlideData.bgPattern === "waves" && (
          <div className="absolute inset-0 opacity-3">
            <svg
              className="absolute inset-0 w-full h-full"
              viewBox="0 0 1200 800"
            >
              <path
                d="M0,200 Q300,100 600,200 T1200,200 L1200,800 L0,800 Z"
                fill="#e879f9"
                opacity="0.1"
                className="animate-pulse"
              />
              <path
                d="M0,300 Q300,200 600,300 T1200,300 L1200,800 L0,800 Z"
                fill="#a855f7"
                opacity="0.1"
                className="animate-pulse"
                style={{ animationDelay: "1s" }}
              />
            </svg>
          </div>
        )}

        {currentSlideData.bgPattern === "dots" && (
          <div className="absolute inset-0 opacity-3">
            <div className="absolute top-16 left-1/4 w-3 h-3 bg-emerald-300 rounded-full animate-bounce"></div>
            <div
              className="absolute top-40 right-1/4 w-2 h-2 bg-teal-300 rounded-full animate-bounce"
              style={{ animationDelay: "0.5s" }}
            ></div>
            <div
              className="absolute bottom-32 left-1/3 w-4 h-4 bg-emerald-200 rounded-full animate-bounce"
              style={{ animationDelay: "1s" }}
            ></div>
            <div
              className="absolute bottom-16 right-1/3 w-3 h-3 bg-teal-200 rounded-full animate-bounce"
              style={{ animationDelay: "1.5s" }}
            ></div>
          </div>
        )}
      </div>

      {/* Skip Button */}
      <div className="absolute top-6 right-6 z-20">
        <button
          onClick={handleSkip}
          className="px-4 py-2 text-sm text-gray-500 hover:text-gray-700 transition-colors"
        >
          Salta
        </button>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex items-center justify-center px-8 relative z-10">
        <div className="max-w-md w-full text-center">
          {/* Icon Section */}
          <div className="mb-12">
            <div
              className={`relative inline-block transition-all duration-700 ${
                isTransitioning
                  ? "scale-95 opacity-70"
                  : "scale-100 opacity-100"
              }`}
            >
              <div
                className={`w-32 h-32 rounded-full bg-gradient-to-br ${currentSlideData.color} flex items-center justify-center mx-auto shadow-2xl`}
              >
                <IconComponent className="w-16 h-16 text-white drop-shadow-lg" />
              </div>

              {/* Animated Ring */}
              <div
                className={`absolute inset-0 w-32 h-32 rounded-full bg-gradient-to-br ${currentSlideData.color} opacity-20 animate-ping`}
              ></div>
              <div
                className={`absolute inset-0 w-32 h-32 rounded-full bg-gradient-to-br ${currentSlideData.color} opacity-10 animate-pulse`}
              ></div>
            </div>
          </div>

          {/* Text Content */}
          <div
            className={`space-y-6 transition-all duration-500 ${
              isTransitioning
                ? "opacity-0 translate-y-8"
                : "opacity-100 translate-y-0"
            }`}
          >
            <div className="space-y-3">
              <h1 className="text-4xl font-bold text-gray-900 leading-tight">
                {currentSlideData.title}
              </h1>
              <p className="text-xl text-gray-600 font-medium">
                {currentSlideData.subtitle}
              </p>
            </div>

            <p className="text-gray-500 leading-relaxed text-lg px-4">
              {currentSlideData.description}
            </p>
          </div>
        </div>
      </div>

      {/* Bottom Section */}
      <div className="pb-12 px-8 relative z-10">
        <div className="max-w-md mx-auto">
          {/* Progress Indicator */}
          <div className="mb-8">
            <div className="flex justify-center space-x-2 mb-4">
              {slides.map((_, index) => (
                <button
                  key={index}
                  onClick={() => goToSlide(index)}
                  className={`transition-all duration-300 ${
                    index === currentSlide
                      ? `w-8 h-2 rounded-full bg-gradient-to-r ${currentSlideData.color}`
                      : "w-2 h-2 rounded-full bg-gray-300 hover:bg-gray-400"
                  }`}
                />
              ))}
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-gray-200 rounded-full h-1">
              <div
                className={`h-1 rounded-full bg-gradient-to-r ${currentSlideData.color} transition-all duration-500`}
                style={{
                  width: `${((currentSlide + 1) / slides.length) * 100}%`,
                }}
              ></div>
            </div>
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-between">
            <button
              onClick={prevSlide}
              disabled={currentSlide === 0}
              className={`flex items-center justify-center w-12 h-12 rounded-full transition-all duration-300 ${
                currentSlide === 0
                  ? "bg-gray-100 text-gray-400 cursor-not-allowed"
                  : "bg-gray-100 text-gray-600 hover:bg-gray-200 hover:scale-105 active:scale-95"
              }`}
            >
              <ChevronLeft className="w-6 h-6" />
            </button>

            <div className="text-center">
              <p className="text-sm text-gray-500 mb-2">
                {currentSlide + 1} di {slides.length}
              </p>
            </div>

            <button
              onClick={handleContinue}
              className={`flex items-center justify-center w-12 h-12 rounded-full bg-gradient-to-r ${currentSlideData.color} text-white transition-all duration-300 hover:scale-105 active:scale-95 shadow-lg`}
            >
              {currentSlide === slides.length - 1 ? (
                <ArrowRight className="w-6 h-6" />
              ) : (
                <ChevronRight className="w-6 h-6" />
              )}
            </button>
          </div>

          {/* Continue Button */}
          <button
            onClick={handleContinue}
            className={`w-full mt-6 py-4 px-6 rounded-2xl bg-gradient-to-r ${currentSlideData.color} text-white font-semibold text-lg transition-all duration-300 hover:shadow-xl hover:scale-[1.02] active:scale-[0.98]`}
          >
            {currentSlide === slides.length - 1 ? "Inizia ora" : "Continua"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default OnboardingSlides;
