import React, { useState, useEffect } from "react";
import {
  ChevronLeft,
  ChevronRight,
  User,
  Camera,
  Target,
  Globe,
  Star,
  Trophy,
  Heart,
  Sparkles,
  ArrowRight,
  Upload,
  X,
  Plus,
  Crown,
  Flame,
  Phone,
  Mail,
} from "lucide-react";
import { useOnboarding } from "../Context/OnboardingContext"; // IMPORTA CONTEXTO
import { playSound, SOUNDS } from "../../utils/soundUtils"; // IMPORTA UTILITY

const QuickSetupSlides = () => {
  const { setShowQuickSetup, completeOnboarding } = useOnboarding();

  const [currentStep, setCurrentStep] = useState(0);
  const [xp, setXp] = useState(0);
  const [level, setLevel] = useState(1);
  const [achievements, setAchievements] = useState([]);
  const [showAchievement, setShowAchievement] = useState(null);
  const [showWelcome, setShowWelcome] = useState(false);
  const [isExiting, setIsExiting] = useState(false);

  // Dati del profilo
  const [profileData, setProfileData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    birthDate: "",
    profilePhoto: null,
    skills: [],
    wantedSkills: [],
    languages: [],
    location: "",
    aboutMe: "",
    eventSuggestions: true,
  });

  const compliments = [
    "Fantastico! 🎉",
    "Sei un mito! 🌟",
    "Incredibile! 🚀",
    "Wow! 🔥",
    "Perfetto! ✨",
    "Geniale! 💎",
    "Straordinario! 🎯",
    "Magnifico! 🏆",
  ];

  const skillsData = [
    { id: "writing", name: "Scrittura", icon: "✍️" },
    { id: "cooking", name: "Cucina", icon: "🍳" },
    { id: "photography", name: "Fotografia", icon: "📸" },
    { id: "history", name: "Storia", icon: "📚" },
    { id: "music", name: "Musica", icon: "🎵" },
    { id: "dance", name: "Danza", icon: "💃" },
    { id: "painting", name: "Pittura", icon: "🎨" },
    { id: "video", name: "Video", icon: "🎬" },
    { id: "architecture", name: "Architettura", icon: "🏛️" },
    { id: "graphics", name: "Grafica", icon: "🎭" },
    { id: "theater", name: "Teatro", icon: "🎪" },
    { id: "psychology", name: "Psicologia", icon: "🧠" },
    { id: "programming", name: "Programmazione", icon: "💻" },
    { id: "fashion", name: "Fashion", icon: "👗" },
    { id: "health", name: "Salute", icon: "💪" },
    { id: "gardening", name: "Giardinaggio", icon: "🌱" },
    { id: "languages", name: "Lingue", icon: "🗣️" },
    { id: "videogames", name: "Videogiochi", icon: "🎮" },
    { id: "podcast", name: "Podcast", icon: "🎙️" },
  ];

  const languagesData = [
    { name: "Italiano", flag: "🇮🇹" },
    { name: "Inglese", flag: "🇬🇧" },
    { name: "Francese", flag: "🇫🇷" },
    { name: "Spagnolo", flag: "🇪🇸" },
    { name: "Tedesco", flag: "🇩🇪" },
    { name: "Portoghese", flag: "🇵🇹" },
    { name: "Russo", flag: "🇷🇺" },
    { name: "Cinese", flag: "🇨🇳" },
    { name: "Giapponese", flag: "🇯🇵" },
    { name: "Arabo", flag: "🇸🇦" },
  ];

  const steps = [
    {
      title: "Chi sei tu?",
      subtitle: "Iniziamo con le basi, campione! 🌟",
      component: "identity",
      xpReward: 100,
    },
    {
      title: "I tuoi superpoteri",
      subtitle: "Mostraci di cosa sei capace! 💪",
      component: "skills",
      xpReward: 150,
    },
    {
      title: "Cosa vuoi imparare?",
      subtitle: "Scegli la tua prossima avventura! 🎯",
      component: "learning",
      xpReward: 125,
    },
    {
      title: "Dove trovarti",
      subtitle: "Lingue e posizione per connetterti! 🌍",
      component: "location",
      xpReward: 100,
    },
    {
      title: "Il tocco finale",
      subtitle: "Personalizza il tuo profilo! ✨",
      component: "final",
      xpReward: 200,
    },
  ];

  const achievementsList = [
    {
      id: "first_skill",
      name: "Primo Talento",
      description: "Hai aggiunto la tua prima skill!",
      icon: "🎯",
    },
    {
      id: "skill_master",
      name: "Maestro delle Skill",
      description: "3+ competenze aggiunte!",
      icon: "🏆",
    },
    {
      id: "polyglot",
      name: "Poliglotta",
      description: "Parli 3+ lingue!",
      icon: "🗣️",
    },
    {
      id: "learner",
      name: "Eterno Studente",
      description: "Vuoi imparare 5+ cose nuove!",
      icon: "📚",
    },
    {
      id: "complete",
      name: "Profilo Completo",
      description: "Hai completato tutto!",
      icon: "👑",
    },
  ];

  // Auto-scroll al top quando cambia step
  useEffect(() => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  }, [currentStep]);

  // Scroll iniziale
  useEffect(() => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  }, []);

  // Sistema livelli
  useEffect(() => {
    const newLevel = Math.floor(xp / 200) + 1;
    if (newLevel > level) {
      setLevel(newLevel);
      triggerAchievement({
        id: "level_up",
        name: `Livello ${newLevel}!`,
        description: "Continua così!",
        icon: "🚀",
      });
    }
  }, [xp, level]);

  const triggerAchievement = (achievement) => {
    if (!achievements.find((a) => a.id === achievement.id)) {
      setAchievements([...achievements, achievement]);
      setShowAchievement(achievement);
      playSound(SOUNDS.ACHIEVEMENT);
      setTimeout(() => setShowAchievement(null), 3000);
    }
  };

  const addXP = (amount) => {
    setXp((prev) => prev + amount);
  };

  const getRandomCompliment = () => {
    return compliments[Math.floor(Math.random() * compliments.length)];
  };

  const handleNext = () => {
    // Suono di successo
    playSound(SOUNDS.SUCCESS);

    // Aggiungi XP per completare lo step
    addXP(steps[currentStep].xpReward);

    // Controlla achievements
    checkAchievements();

    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      // Completa setup - mostra welcome screen
      triggerAchievement(achievementsList.find((a) => a.id === "complete"));
      setIsExiting(true);
      setTimeout(() => {
        setShowWelcome(true);
      }, 500);
      setTimeout(() => {
        // Usa la funzione completeOnboarding dal context
        completeOnboarding({
          ...profileData,
          xp,
          level,
          achievements,
        });
      }, 4000);
    }
  };

  const checkAchievements = () => {
    if (profileData.skills.length === 1) {
      triggerAchievement(achievementsList.find((a) => a.id === "first_skill"));
    }
    if (profileData.skills.length >= 3) {
      triggerAchievement(achievementsList.find((a) => a.id === "skill_master"));
    }
    if (profileData.languages.length >= 3) {
      triggerAchievement(achievementsList.find((a) => a.id === "polyglot"));
    }
    if (profileData.wantedSkills.length >= 5) {
      triggerAchievement(achievementsList.find((a) => a.id === "learner"));
    }
  };

  const handlePrev = () => {
    playSound(SOUNDS.CLICK);
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const canContinue = () => {
    switch (currentStep) {
      case 0:
        return (
          profileData.firstName &&
          profileData.lastName &&
          (profileData.email || profileData.phone)
        );
      case 1:
        return profileData.skills.length > 0;
      case 2:
        return profileData.wantedSkills.length > 0;
      case 3:
        return profileData.languages.length > 0;
      case 4:
        return true;
      default:
        return false;
    }
  };

  const toggleSkill = (skill) => {
    const exists = profileData.skills.find((s) => s.id === skill.id);
    if (exists) {
      setProfileData((prev) => ({
        ...prev,
        skills: prev.skills.filter((s) => s.id !== skill.id),
      }));
    } else {
      setProfileData((prev) => ({
        ...prev,
        skills: [...prev.skills, skill],
      }));
      playSound(SOUNDS.CLICK);
    }
  };

  const toggleWantedSkill = (skill) => {
    const exists = profileData.wantedSkills.find((s) => s.id === skill.id);
    if (exists) {
      setProfileData((prev) => ({
        ...prev,
        wantedSkills: prev.wantedSkills.filter((s) => s.id !== skill.id),
      }));
    } else {
      setProfileData((prev) => ({
        ...prev,
        wantedSkills: [...prev.wantedSkills, skill],
      }));
      playSound(SOUNDS.CLICK);
    }
  };

  const toggleLanguage = (language) => {
    const exists = profileData.languages.find((l) => l.name === language.name);
    if (exists) {
      setProfileData((prev) => ({
        ...prev,
        languages: prev.languages.filter((l) => l.name !== language.name),
      }));
    } else {
      setProfileData((prev) => ({
        ...prev,
        languages: [...prev.languages, { ...language, level: "Intermedio" }],
      }));
      playSound(SOUNDS.CLICK);
    }
  };

  // Welcome Screen
  if (showWelcome) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-600 via-pink-600 to-blue-600 flex items-center justify-center relative overflow-hidden">
        {/* Background Animation */}
        <div className="absolute inset-0">
          <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-white rounded-full mix-blend-overlay filter blur-xl opacity-20 animate-pulse"></div>
          <div
            className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-white rounded-full mix-blend-overlay filter blur-xl opacity-20 animate-pulse"
            style={{ animationDelay: "1s" }}
          ></div>
          <div
            className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-white rounded-full mix-blend-overlay filter blur-xl opacity-20 animate-pulse"
            style={{ animationDelay: "2s" }}
          ></div>
        </div>

        {/* Content */}
        <div className="text-center text-white z-10 px-8">
          <div className="mb-8">
            <Crown className="w-24 h-24 mx-auto text-yellow-300 animate-pulse" />
          </div>
          <h1 className="text-4xl md:text-6xl font-bold mb-6 animate-pulse">
            Benvenuto {profileData.firstName}!
          </h1>
          <p
            className="text-xl md:text-2xl opacity-90 animate-pulse"
            style={{ animationDelay: "0.5s" }}
          >
            Il tuo profilo da campione è pronto! 🎉
          </p>
        </div>
      </div>
    );
  }

  const renderGameHUD = () => (
    <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white p-3 md:p-4 rounded-2xl mb-4 md:mb-6 shadow-xl">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2 md:space-x-4">
          <div className="flex items-center space-x-1 md:space-x-2">
            <Crown className="w-4 h-4 md:w-6 md:h-6 text-yellow-300" />
            <span className="text-sm md:text-xl font-bold">
              Livello {level}
            </span>
          </div>
          <div className="flex items-center space-x-1 md:space-x-2">
            <Star className="w-3 h-3 md:w-5 md:h-5 text-yellow-300" />
            <span className="text-xs md:text-base font-semibold">{xp} XP</span>
          </div>
        </div>
        <div className="flex items-center space-x-1 md:space-x-2">
          <Trophy className="w-3 h-3 md:w-5 md:h-5 text-yellow-300" />
          <span className="text-xs md:text-base font-semibold">
            {achievements.length}
          </span>
        </div>
      </div>

      <div className="mt-2 md:mt-3">
        <div className="flex items-center justify-between text-xs md:text-sm mb-1">
          <span>Progresso Profilo</span>
          <span>{Math.round((currentStep / (steps.length - 1)) * 100)}%</span>
        </div>
        <div className="w-full bg-purple-800 rounded-full h-1.5 md:h-2">
          <div
            className="bg-yellow-400 h-1.5 md:h-2 rounded-full transition-all duration-500"
            style={{ width: `${(currentStep / (steps.length - 1)) * 100}%` }}
          ></div>
        </div>
      </div>
    </div>
  );

  const renderIdentityStep = () => (
    <div className="space-y-4 md:space-y-6">
      {/* Avatar Selection */}
      <div className="text-center mb-6 md:mb-8">
        <div className="relative inline-block">
          <div className="w-24 h-24 md:w-32 md:h-32 mx-auto mb-4 bg-gradient-to-br from-purple-400 to-pink-400 rounded-full flex items-center justify-center overflow-hidden shadow-2xl">
            {profileData.profilePhoto ? (
              <img
                src={URL.createObjectURL(profileData.profilePhoto)}
                alt="Profile"
                className="w-full h-full object-cover"
              />
            ) : (
              <User className="w-12 h-12 md:w-16 md:h-16 text-white" />
            )}
          </div>
          <label className="absolute bottom-0 right-0 bg-purple-500 text-white p-1.5 md:p-2 rounded-full cursor-pointer hover:bg-purple-600 transition-colors shadow-lg">
            <input
              type="file"
              accept="image/*"
              onChange={(e) => {
                setProfileData((prev) => ({
                  ...prev,
                  profilePhoto: e.target.files[0],
                }));
                playSound(SOUNDS.CLICK);
              }}
              className="hidden"
            />
            <Camera className="w-4 h-4 md:w-5 md:h-5" />
          </label>
        </div>
      </div>

      {/* Form Fields */}
      <div className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="relative">
            <input
              type="text"
              value={profileData.firstName}
              onChange={(e) =>
                setProfileData((prev) => ({
                  ...prev,
                  firstName: e.target.value,
                }))
              }
              className="w-full p-3 md:p-4 border-2 border-purple-200 rounded-xl focus:border-purple-500 focus:ring-0 transition-colors text-base md:text-lg pr-6"
              placeholder="Nome"
            />
            <span className="absolute right-3 top-3 md:top-4 text-red-500 font-bold">
              *
            </span>
          </div>
          <div className="relative">
            <input
              type="text"
              value={profileData.lastName}
              onChange={(e) =>
                setProfileData((prev) => ({
                  ...prev,
                  lastName: e.target.value,
                }))
              }
              className="w-full p-3 md:p-4 border-2 border-purple-200 rounded-xl focus:border-purple-500 focus:ring-0 transition-colors text-base md:text-lg pr-6"
              placeholder="Cognome"
            />
            <span className="absolute right-3 top-3 md:top-4 text-red-500 font-bold">
              *
            </span>
          </div>
        </div>

        <div className="relative">
          <div className="flex items-center space-x-2 p-3 md:p-4 border-2 border-purple-200 rounded-xl focus-within:border-purple-500 transition-colors">
            <Mail className="w-5 h-5 text-purple-500" />
            <input
              type="email"
              value={profileData.email}
              onChange={(e) =>
                setProfileData((prev) => ({ ...prev, email: e.target.value }))
              }
              className="flex-1 outline-none text-base md:text-lg"
              placeholder="Email"
            />
          </div>
          <span className="absolute right-3 top-3 md:top-4 text-red-500 font-bold">
            *
          </span>
        </div>

        <div className="text-center text-sm text-gray-500">oppure</div>

        <div className="flex items-center space-x-2 p-3 md:p-4 border-2 border-purple-200 rounded-xl focus-within:border-purple-500 transition-colors">
          <Phone className="w-5 h-5 text-purple-500" />
          <input
            type="tel"
            value={profileData.phone}
            onChange={(e) =>
              setProfileData((prev) => ({ ...prev, phone: e.target.value }))
            }
            className="flex-1 outline-none text-base md:text-lg"
            placeholder="Numero di telefono"
          />
        </div>

        <div className="relative">
          <input
            type="date"
            value={profileData.birthDate}
            onChange={(e) =>
              setProfileData((prev) => ({ ...prev, birthDate: e.target.value }))
            }
            className="w-full p-3 md:p-4 border-2 border-purple-200 rounded-xl focus:border-purple-500 focus:ring-0 transition-colors text-base md:text-lg pr-6"
          />
          <span className="absolute right-3 top-3 md:top-4 text-red-500 font-bold">
            *
          </span>
        </div>
      </div>
    </div>
  );

  const renderSkillsStep = () => (
    <div className="space-y-4 md:space-y-6">
      <div className="text-center mb-4 md:mb-6">
        <p className="text-base md:text-lg text-gray-600">
          Seleziona le tue competenze! 🎯
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 md:gap-4">
        {skillsData.map((skill) => {
          const isSelected = profileData.skills.find((s) => s.id === skill.id);
          return (
            <div
              key={skill.id}
              className={`p-3 md:p-4 rounded-xl border-2 cursor-pointer transition-all duration-300 ${
                isSelected
                  ? "border-purple-500 bg-purple-50 shadow-lg transform scale-105"
                  : "border-gray-200 hover:border-purple-300 hover:shadow-md"
              }`}
              onClick={() => toggleSkill(skill)}
            >
              <div className="flex flex-col items-center space-y-2">
                <span className="text-2xl md:text-3xl">{skill.icon}</span>
                <span className="font-medium text-gray-900 text-xs md:text-sm text-center">
                  {skill.name}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      <div className="text-center">
        <p className="text-sm text-gray-600">
          Selezionate: {profileData.skills.length} competenze
        </p>
      </div>
    </div>
  );

  const renderLearningStep = () => (
    <div className="space-y-4 md:space-y-6">
      <div className="text-center mb-4 md:mb-6">
        <p className="text-base md:text-lg text-gray-600">
          Cosa ti piacerebbe imparare? Scegli le tue prossime avventure! 🚀
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 md:gap-4">
        {skillsData.map((skill) => {
          const isSelected = profileData.wantedSkills.find(
            (s) => s.id === skill.id
          );
          return (
            <div
              key={skill.id}
              className={`p-3 md:p-4 rounded-xl border-2 cursor-pointer transition-all duration-300 transform hover:scale-105 ${
                isSelected
                  ? "border-green-500 bg-green-50 shadow-lg"
                  : "border-gray-200 hover:border-green-300 hover:shadow-md"
              }`}
              onClick={() => toggleWantedSkill(skill)}
            >
              <div className="flex flex-col items-center space-y-2">
                <span className="text-2xl md:text-3xl">{skill.icon}</span>
                <span className="font-medium text-gray-900 text-xs md:text-sm text-center">
                  {skill.name}
                </span>
                {isSelected && <Heart className="w-4 h-4 text-red-500" />}
              </div>
            </div>
          );
        })}
      </div>

      <div className="text-center">
        <p className="text-sm text-gray-600">
          Selezionate: {profileData.wantedSkills.length} competenze da imparare
        </p>
      </div>
    </div>
  );

  const renderLocationStep = () => (
    <div className="space-y-6 md:space-y-8">
      <div>
        <h3 className="text-lg md:text-xl font-semibold text-gray-900 mb-4 flex items-center">
          <Globe className="w-5 h-5 md:w-6 md:h-6 mr-2 text-blue-500" />
          Che lingue parli?
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {languagesData.map((language) => {
            const isSelected = profileData.languages.find(
              (l) => l.name === language.name
            );
            return (
              <div
                key={language.name}
                className={`p-3 rounded-xl border-2 cursor-pointer transition-all duration-300 ${
                  isSelected
                    ? "border-blue-500 bg-blue-50 shadow-md"
                    : "border-gray-200 hover:border-blue-300 hover:shadow-sm"
                }`}
                onClick={() => toggleLanguage(language)}
              >
                <div className="flex items-center space-x-2 md:space-x-3">
                  <span className="text-xl md:text-2xl">{language.flag}</span>
                  <span className="font-medium text-gray-900 text-sm md:text-base">
                    {language.name}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div>
        <h3 className="text-lg md:text-xl font-semibold text-gray-900 mb-4 flex items-center">
          <Target className="w-5 h-5 md:w-6 md:h-6 mr-2 text-purple-500" />
          Dove ti nascondi?
        </h3>
        <input
          type="text"
          value={profileData.location}
          onChange={(e) =>
            setProfileData((prev) => ({ ...prev, location: e.target.value }))
          }
          className="w-full p-3 md:p-4 border-2 border-purple-200 rounded-xl focus:border-purple-500 focus:ring-0 transition-colors text-base md:text-lg"
          placeholder="La tua città"
        />
      </div>
    </div>
  );

  const renderFinalStep = () => (
    <div className="space-y-4 md:space-y-6">
      <div>
        <h3 className="text-lg md:text-xl font-semibold text-gray-900 mb-4 flex items-center">
          <Sparkles className="w-5 h-5 md:w-6 md:h-6 mr-2 text-yellow-500" />
          Raccontaci di te!
        </h3>
        <textarea
          value={profileData.aboutMe}
          onChange={(e) =>
            setProfileData((prev) => ({ ...prev, aboutMe: e.target.value }))
          }
          className="w-full p-3 md:p-4 border-2 border-purple-200 rounded-xl focus:border-purple-500 focus:ring-0 transition-colors text-base md:text-lg"
          rows="4"
          placeholder="Scrivi qualcosa di interessante su di te..."
        />
      </div>

      <div className="flex items-center justify-between p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl">
        <div>
          <h4 className="font-semibold text-gray-900 text-sm md:text-base">
            Suggerimenti eventi 🎪
          </h4>
          <p className="text-xs md:text-sm text-gray-600">
            Ricevi notifiche su eventi fighi nella tua zona
          </p>
        </div>
        <button
          onClick={() => {
            setProfileData((prev) => ({
              ...prev,
              eventSuggestions: !prev.eventSuggestions,
            }));
            playSound(SOUNDS.CLICK);
          }}
          className={`w-12 h-6 rounded-full transition-all ${
            profileData.eventSuggestions ? "bg-purple-500" : "bg-gray-300"
          }`}
        >
          <div
            className={`w-5 h-5 bg-white rounded-full transition-all ${
              profileData.eventSuggestions ? "translate-x-6" : "translate-x-1"
            }`}
          ></div>
        </button>
      </div>

      {currentStep === steps.length - 1 && (
        <div className="text-center p-4 md:p-6 bg-gradient-to-r from-green-50 to-blue-50 rounded-xl">
          <Trophy className="w-12 h-12 md:w-16 md:h-16 text-yellow-500 mx-auto mb-4" />
          <h3 className="text-xl md:text-2xl font-bold text-gray-900 mb-2">
            Quasi pronto! 🎉
          </h3>
          <p className="text-gray-600 text-sm md:text-base">
            Stai per completare il tuo profilo da campione!
          </p>
        </div>
      )}
    </div>
  );

  const renderStepContent = () => {
    switch (steps[currentStep].component) {
      case "identity":
        return renderIdentityStep();
      case "skills":
        return renderSkillsStep();
      case "learning":
        return renderLearningStep();
      case "location":
        return renderLocationStep();
      case "final":
        return renderFinalStep();
      default:
        return null;
    }
  };

  return (
    <div
      className={`min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 relative overflow-hidden transition-all duration-500 ${
        isExiting ? "opacity-0 scale-95" : "opacity-100 scale-100"
      }`}
    >
      {/* Background Elements */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-20 left-20 w-32 h-32 md:w-64 md:h-64 bg-gradient-to-br from-purple-200 to-pink-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse"></div>
        <div
          className="absolute bottom-20 right-20 w-32 h-32 md:w-64 md:h-64 bg-gradient-to-br from-blue-200 to-purple-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse"
          style={{ animationDelay: "1s" }}
        ></div>
      </div>

      {/* Achievement Popup */}
      {showAchievement && (
        <div className="fixed top-4 right-4 z-50 bg-gradient-to-r from-yellow-400 to-orange-400 text-white p-3 md:p-4 rounded-xl shadow-2xl animate-bounce max-w-xs">
          <div className="flex items-center space-x-2 md:space-x-3">
            <span className="text-xl md:text-2xl">{showAchievement.icon}</span>
            <div>
              <h4 className="font-bold text-sm md:text-base">
                {showAchievement.name}
              </h4>
              <p className="text-xs md:text-sm">
                {showAchievement.description}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="relative z-10 min-h-screen flex flex-col px-4 md:px-8 py-4 md:py-8">
        {/* Game HUD */}
        {renderGameHUD()}

        {/* Step Header */}
        <div className="text-center mb-6 md:mb-8">
          <h1 className="text-2xl md:text-4xl font-bold text-gray-900 mb-2">
            {steps[currentStep].title}
          </h1>
          <p className="text-base md:text-xl text-gray-600">
            {steps[currentStep].subtitle}
          </p>
        </div>

        {/* Content */}
        <div className="flex-1 max-w-4xl mx-auto w-full">
          {renderStepContent()}
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between mt-6 md:mt-8 max-w-4xl mx-auto w-full">
          <button
            onClick={handlePrev}
            disabled={currentStep === 0}
            className={`flex items-center space-x-2 px-4 md:px-6 py-2 md:py-3 rounded-xl transition-all duration-300 ${
              currentStep === 0
                ? "text-gray-400 cursor-not-allowed"
                : "bg-white text-gray-700 hover:bg-gray-50 shadow-md hover:shadow-lg"
            }`}
          >
            <ChevronLeft className="w-4 h-4 md:w-5 md:h-5" />
            <span className="text-sm md:text-base">Indietro</span>
          </button>

          <div className="flex space-x-1 md:space-x-2">
            {steps.map((_, index) => (
              <div
                key={index}
                className={`w-8 md:w-12 h-1.5 md:h-2 rounded-full transition-all duration-300 ${
                  index === currentStep
                    ? "bg-purple-500"
                    : index < currentStep
                    ? "bg-green-500"
                    : "bg-gray-300"
                }`}
              />
            ))}
          </div>

          <button
            onClick={handleNext}
            disabled={!canContinue()}
            className={`flex items-center space-x-2 px-4 md:px-6 py-2 md:py-3 rounded-xl transition-all duration-300 ${
              canContinue()
                ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600 shadow-lg hover:shadow-xl transform hover:scale-105"
                : "bg-gray-300 text-gray-500 cursor-not-allowed"
            }`}
          >
            <span className="text-sm md:text-base">
              {currentStep === steps.length - 1
                ? "Profilo Completo! 🎉"
                : "Avanti"}
            </span>
            {currentStep === steps.length - 1 ? (
              <Flame className="w-4 h-4 md:w-5 md:h-5" />
            ) : (
              <ChevronRight className="w-4 h-4 md:w-5 md:h-5" />
            )}
          </button>
        </div>

        {/* Motivational Message */}
        <div className="text-center mt-2 md:mt-4">
          <p className="text-xs md:text-sm text-gray-600">
            {canContinue()
              ? getRandomCompliment()
              : "Completa questo step per continuare!"}
          </p>
        </div>
      </div>
    </div>
  );
};

export default QuickSetupSlides;
