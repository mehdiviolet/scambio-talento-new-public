import React, { useState, useEffect } from "react";
import { playSound, SOUNDS } from "../../utils/soundUtils"; // IMPORTA UTILITY
import {
  Users,
  MessageCircle,
  Calendar,
  Sparkles,
  ArrowRight,
  CheckCircle,
} from "lucide-react";
import { useOnboarding } from "../Context/OnboardingContext"; // IMPORTA CONTEXTO

const ReadyToStartSlide = () => {
  const { setShowReadyToStart, setShowQuickSetup } = useOnboarding();
  const [animationStep, setAnimationStep] = useState(0);
  const [isExiting, setIsExiting] = useState(false);

  useEffect(() => {
    const timer1 = setTimeout(() => setAnimationStep(1), 500);
    const timer2 = setTimeout(() => setAnimationStep(2), 1000);
    const timer3 = setTimeout(() => setAnimationStep(3), 1500);
    const timer4 = setTimeout(() => setAnimationStep(4), 2000);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
      clearTimeout(timer4);
    };
  }, []);

  // Rimuovi la funzione playSound locale

  const handleContinue = () => {
    console.log("Continuing to quick setup...");

    // Suono di transizione
    playSound(SOUNDS.TRANSITION);

    // Anima l'uscita
    setIsExiting(true);

    // Dopo l'animazione, cambia schermata
    setTimeout(() => {
      setShowReadyToStart(false);
      setShowQuickSetup(true);
    }, 800); // Durata animazione uscita
  };

  const features = [
    {
      icon: Users,
      title: "Connetti",
      description: "Persone con tue passioni",
      color: "from-blue-500 to-cyan-500",
    },
    {
      icon: MessageCircle,
      title: "Scambia",
      description: "Competenze e conoscenze",
      color: "from-purple-500 to-pink-500",
    },
    {
      icon: Calendar,
      title: "Organizza",
      description: "Eventi e workshop",
      color: "from-emerald-500 to-teal-500",
    },
  ];

  return (
    <div
      className={`min-h-screen bg-gradient-to-br from-indigo-50 via-white to-cyan-50 flex flex-col items-center justify-center px-8 relative overflow-hidden transition-all duration-800 ${
        isExiting
          ? "opacity-0 scale-95 -translate-y-8"
          : "opacity-100 scale-100 translate-y-0"
      }`}
    >
      {/* Background Animation */}
      <div className="absolute inset-0 z-0">
        <div
          className={`absolute top-20 left-20 w-64 h-64 bg-gradient-to-br from-blue-200 to-purple-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse transition-all duration-800 ${
            isExiting ? "scale-0 opacity-0" : "scale-100 opacity-70"
          }`}
        ></div>
        <div
          className={`absolute top-40 right-20 w-64 h-64 bg-gradient-to-br from-cyan-200 to-pink-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse transition-all duration-800 ${
            isExiting ? "scale-0 opacity-0" : "scale-100 opacity-70"
          }`}
          style={{ animationDelay: "1s" }}
        ></div>
        <div
          className={`absolute bottom-20 left-1/2 transform -translate-x-1/2 w-64 h-64 bg-gradient-to-br from-purple-200 to-emerald-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse transition-all duration-800 ${
            isExiting ? "scale-0 opacity-0" : "scale-100 opacity-70"
          }`}
          style={{ animationDelay: "2s" }}
        ></div>
      </div>

      {/* Main Content */}
      <div
        className={`relative z-10 text-center max-w-lg transition-all duration-800 ${
          isExiting
            ? "opacity-0 scale-90 -translate-y-12"
            : "opacity-100 scale-100 translate-y-0"
        }`}
      >
        {/* Hero Icon */}
        <div
          className={`mb-8 transition-all duration-1000 ${
            animationStep >= 1 && !isExiting
              ? "scale-100 opacity-100"
              : "scale-0 opacity-0"
          }`}
        >
          <div className="relative inline-block">
            <div className="w-24 h-24 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-full flex items-center justify-center mx-auto shadow-2xl">
              <Sparkles className="w-12 h-12 text-white" />
            </div>
            <div className="absolute inset-0 w-24 h-24 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-full opacity-20 animate-ping"></div>
          </div>
        </div>

        {/* Title */}
        <div
          className={`mb-8 transition-all duration-1000 delay-300 ${
            animationStep >= 2 && !isExiting
              ? "translate-y-0 opacity-100"
              : "translate-y-8 opacity-0"
          }`}
        >
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Sei pronto a iniziare!
          </h1>
          <p className="text-xl text-gray-600">
            Tutto quello che ti serve per condividere e imparare
          </p>
        </div>

        {/* Features Recap */}
        <div
          className={`mb-10 transition-all duration-1000 delay-500 ${
            animationStep >= 3 && !isExiting
              ? "translate-y-0 opacity-100"
              : "translate-y-8 opacity-0"
          }`}
        >
          <div className="grid gap-4">
            {features.map((feature, index) => {
              const IconComponent = feature.icon;
              return (
                <div
                  key={index}
                  className={`flex items-center p-4 bg-white rounded-xl shadow-sm border transition-all duration-500 hover:shadow-md ${
                    isExiting
                      ? "-translate-x-8 opacity-0"
                      : "translate-x-0 opacity-100"
                  }`}
                  style={{ animationDelay: `${index * 200}ms` }}
                >
                  <div
                    className={`w-12 h-12 bg-gradient-to-br ${feature.color} rounded-full flex items-center justify-center mr-4 flex-shrink-0`}
                  >
                    <IconComponent className="w-6 h-6 text-white" />
                  </div>
                  <div className="text-left flex-1">
                    <h3 className="font-semibold text-gray-900">
                      {feature.title}
                    </h3>
                    <p className="text-sm text-gray-600">
                      {feature.description}
                    </p>
                  </div>
                  <CheckCircle className="w-6 h-6 text-green-500 ml-2" />
                </div>
              );
            })}
          </div>
        </div>

        {/* CTA Button */}
        <div
          className={`transition-all duration-1000 delay-700 ${
            animationStep >= 4 && !isExiting
              ? "translate-y-0 opacity-100"
              : "translate-y-8 opacity-0"
          }`}
        >
          <button
            onClick={handleContinue}
            disabled={isExiting}
            className={`group w-full bg-gradient-to-r from-indigo-500 to-purple-500 text-white font-semibold py-4 px-8 rounded-2xl transition-all duration-300 flex items-center justify-center space-x-2 ${
              isExiting
                ? "opacity-50 cursor-not-allowed scale-95"
                : "hover:shadow-xl hover:scale-[1.02] active:scale-[0.98]"
            }`}
          >
            <span className="text-lg">Inizia la tua avventura</span>
            <ArrowRight
              className={`w-6 h-6 transition-transform ${
                isExiting ? "" : "group-hover:translate-x-1"
              }`}
            />
          </button>

          <p className="text-sm text-gray-500 mt-4">
            Ci vogliono meno di 2 minuti per configurare il tuo profilo
          </p>
        </div>
      </div>

      {/* Floating Elements - animate out during exit */}
      <div
        className={`absolute top-10 left-10 w-8 h-8 bg-yellow-300 rounded-full opacity-60 animate-bounce transition-all duration-800 ${
          isExiting ? "scale-0 opacity-0" : "scale-100 opacity-60"
        }`}
      ></div>
      <div
        className={`absolute top-20 right-16 w-6 h-6 bg-pink-300 rounded-full opacity-60 animate-bounce transition-all duration-800 ${
          isExiting ? "scale-0 opacity-0" : "scale-100 opacity-60"
        }`}
        style={{ animationDelay: "0.5s" }}
      ></div>
      <div
        className={`absolute bottom-16 left-16 w-10 h-10 bg-blue-300 rounded-full opacity-60 animate-bounce transition-all duration-800 ${
          isExiting ? "scale-0 opacity-0" : "scale-100 opacity-60"
        }`}
        style={{ animationDelay: "1s" }}
      ></div>
      <div
        className={`absolute bottom-10 right-10 w-7 h-7 bg-green-300 rounded-full opacity-60 animate-bounce transition-all duration-800 ${
          isExiting ? "scale-0 opacity-0" : "scale-100 opacity-60"
        }`}
        style={{ animationDelay: "1.5s" }}
      ></div>
    </div>
  );
};

export default ReadyToStartSlide;
