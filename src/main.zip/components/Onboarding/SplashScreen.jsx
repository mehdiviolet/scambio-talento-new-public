import React from "react";
import { Sparkles } from "lucide-react";

const SplashScreen = () => (
  <div className="min-h-screen bg-gradient-to-br from-purple-500 via-pink-500 to-blue-500 flex items-center justify-center relative overflow-hidden">
    <div className="absolute inset-0 bg-gradient-to-tr from-cyan-400 via-purple-400 to-pink-400 animate-pulse opacity-30"></div>
    <div className="absolute inset-0 bg-gradient-to-bl from-blue-400 via-indigo-400 to-purple-400 animate-pulse opacity-20" style={{animationDelay: '1s'}}></div>
    
    <div className="text-center relative z-10">
      <div className="mb-8">
        <div className="relative">
          <Sparkles className="w-24 h-24 text-white mx-auto animate-bounce" />
          <div className="absolute inset-0 w-24 h-24 mx-auto animate-ping opacity-20">
            <Sparkles className="w-24 h-24 text-white" />
          </div>
        </div>
      </div>
      
      <h1 className="text-5xl font-bold text-white mb-4 animate-pulse">Scambio Talento</h1>
      <p className="text-xl text-white/90 mb-8 animate-pulse">Dove le competenze si incontrano</p>
      <div className="flex justify-center space-x-2">
        <div className="w-3 h-3 bg-white rounded-full animate-bounce"></div>
        <div className="w-3 h-3 bg-white rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
        <div className="w-3 h-3 bg-white rounded-full animate-bounce" style={{animationDelay: '0.4s'}}></div>
      </div>
    </div>
  </div>
);

export default SplashScreen;