import React, { useEffect } from "react";
import { useOnboarding } from "./Context/OnboardingContext"; // IMPORTA CONTEXTO
import { initAudio } from "../utils/soundUtils"; // IMPORTA UTILITY
import SplashScreen from "./Onboarding/SplashScreen"; // IMPORTA SCHERMATA DI CARICAMENTO
import OnboardingSlides from "./Onboarding/OnboardingSlides"; // IMPORTA SLIDE DI ONBOARDING
import AuthScreen from "./Onboarding/AuthScreen"; // IMPORTA SCHERMATA DI AUTENTICAZIONE
import ReadyToStartSlide from "./Onboarding/ReadyToStartSlide";
import QuickSetupSlides from "./Onboarding/QuickSetupSlides";
//import Dashboard from "./Dashboard";
//import ProfilePage from "./ProfilePage/ProfilePage";

const OnboardingApp = () => {
  const {
    isLoading,
    setIsLoading,
    showOnboarding,
    setShowOnboarding,
    showAuth,
    showReadyToStart,
    showQuickSetup,
    showDashboard,
  } = useOnboarding();

  useEffect(() => {
    // Inizializza sistema audio
    initAudio();

    const timer = setTimeout(() => {
      setIsLoading(false);
      setShowOnboarding(true);
    }, 3000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <>
      {isLoading && <SplashScreen />}
      {showOnboarding && <OnboardingSlides />}
      {showReadyToStart && <ReadyToStartSlide />}
      {showQuickSetup && <QuickSetupSlides />}
      {showAuth && <AuthScreen />}
      {showDashboard && <ProfilePage />} {/* NUOVO COMPONENTE */}
    </>
  );
};

export default OnboardingApp;
