import React, { useEffect } from "react";
import { useOnboarding } from "./Context/OnboardingContext";
import MainAppRouter from "./MainAppRouter";

const OnboardingApp = () => {
  const { isLoading, setIsLoading, showDashboard, setShowDashboard } =
    useOnboarding();

  useEffect(() => {
    // Per ora saltiamo diretto all'app principale
    const timer = setTimeout(() => {
      setIsLoading(false);
      setShowDashboard(true);
    }, 2000);
    return () => clearTimeout(timer);
  }, [setIsLoading, setShowDashboard]);

  // Splash screen semplice
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
        <div className="text-center text-white">
          <div className="text-6xl mb-4">✨</div>
          <h1 className="text-4xl font-bold mb-2">Scambio Talento</h1>
          <p className="text-xl opacity-90">Caricamento...</p>
        </div>
      </div>
    );
  }

  // App principale
  if (showDashboard) {
    return <MainAppRouter />;
  }

  return null;
};

export default OnboardingApp;
