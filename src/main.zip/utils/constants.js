// constants utilities

export const constants = {
  // Implementazione in arrivo...
};

export default constants;
