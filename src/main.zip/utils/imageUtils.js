// imageUtils utilities

export const imageUtils = {
  // Implementazione in arrivo...
};

export default imageUtils;
