// utils/soundUtils.js

/**
 * Riproduce un effetto sonoro
 * @param {string} soundName - Nome del file audio (senza estensione)
 * @param {number} volume - Volume da 0 a 1 (default: 0.3)
 */
export const playSound = (soundName, volume = 0.3) => {
  try {
    const audio = new Audio(`/sounds/${soundName}.mp34`);
    audio.volume = volume;
    audio.play().catch((error) => {
      console.log(`Sound '${soundName}' not available:`, error);
    });
  } catch (error) {
    console.log(`Error playing sound '${soundName}':`, error);
  }
};

/**
 * Precarica i suoni per evitare ritardi
 * @param {Array} soundNames - Array di nomi dei file audio
 */
export const preloadSounds = (soundNames) => {
  soundNames.forEach((soundName) => {
    const audio = new Audio(`/sounds/${soundName}.mp3`);
    audio.preload = "auto";
  });
};

/**
 * Lista dei suoni disponibili nell'app
 */
export const SOUNDS = {
  CLICK: "click",
  SUCCESS: "success",
  ACHIEVEMENT: "achievement",
  TRANSITION: "transition",
  WHOOSH: "whoosh",
  ERROR: "error",
  NOTIFICATION: "notification",
};

/**
 * Inizializza il sistema audio (da chiamare all'avvio dell'app)
 */
export const initAudio = () => {
  const soundList = Object.values(SOUNDS);
  preloadSounds(soundList);
  console.log("Audio system initialized with sounds:", soundList);
};
