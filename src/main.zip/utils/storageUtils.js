// storageUtils utilities

export const storageUtils = {
  // Implementazione in arrivo...
};

export default storageUtils;
